#include<stdio.h>
int main()
{
    int *a;
    printf("%u\n",a);
    int *ptr;
    printf("%u\n",ptr);
}