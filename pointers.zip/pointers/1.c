#include<stdio.h>
int main()
{
    int *p;
    float *q;
    char *r;
    printf("%d %d %d",sizeof(p),sizeof(q),sizeof(r));
}