#include<stdio.h>
int main()
{
    int a=10;
    int *p=&a;
    
    printf("%u\n",*&a);
    printf("%u\n",**&p);
    printf("%u\n",&a);
}