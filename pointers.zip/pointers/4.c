#include<stdio.h>
int main()
{
    int *pc,c;
    c=22;
    printf("%p\n",&c);
    printf("%d\n\n",c);
    pc=&c;
    printf("%p\n",pc);
    printf("%d\n",*pc);
    c=11;
    
}
