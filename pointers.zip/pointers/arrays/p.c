#include<stdio.h>
void swap(int *p,int *q)
{
    int temp;
    temp=*p;
    *p=*q;
    *q=temp;
    printf("%d",*p);
    printf("%d",*q);
}
int main()
{
    int a=10,b=20;
    swap(&a,&b);
    printf("%d",a);
    printf("%d",b);
}