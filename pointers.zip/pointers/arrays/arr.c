#include<stdio.h>
int main()
{
    int z[2]={1,2};
    int *ip=z;         //&z[0]
    printf("%d\n",*ip);
    printf("%u\n",ip);
    /*printf("%d\n",++*ip);
     printf("%d\n",z[0]);
    printf("%d\n",*ip);*/

    printf("%u\n",*++ip);
    printf("%u\n",ip);
}