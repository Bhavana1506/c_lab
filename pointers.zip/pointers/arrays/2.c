#include<stdio.h>
int main()
{
    int a[50],n,i;
    int *ptr=a;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",ptr);
        ptr++;
    }
    for(i=0;i<n;i++)
    {
        printf("%d is at %u",*(ptr+i),(ptr+i));
    }
}