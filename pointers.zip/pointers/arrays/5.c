#include<stdio.h>
#include<string.h>
int main()
{
    int i;
    char *ch;
    char a[50];
    gets(a);
    ch=a;//ch=a[0];
    for(i=0;i<strlen(a);i++)
    {
        printf("%u\n",ch+i);//address
        printf("%c\n",*(ch+i));//charecters
    }
}