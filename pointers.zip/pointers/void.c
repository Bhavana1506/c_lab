#include<stdio.h>
int main()
{
    void *p;
    int a=25;
    p=&a;
    printf("%d",*(int *)p);
}