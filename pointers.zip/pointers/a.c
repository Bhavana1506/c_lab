#include<stdio.h>
int main()
{
    int a=5;
    int *p;
    p=&a;
    int **q=&p;
    printf("%u\n",p);
    printf("%u\n",*p);
    printf("%d\n",q);
    printf("%d\n",*q);
    printf("%d\n",**q);
    int ***d=&q;
    printf("%d\n",d);
    printf("%d\n",***d);
    printf("%u\n",*&*&d);
    printf("%u",*&*d);

}