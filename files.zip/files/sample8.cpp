#include<stdio.h>
#include<string.h>
int main()
{
	FILE *fp;
	int roll;
	float cgpa;
	char name[10];
	int i;
	for(i=0;i<3;i++)
	{
		scanf("%d",&roll);
	    scanf("%f",&cgpa);
	    scanf("%s",name);
	    fprintf(fp,"%d %f %s\n",roll,cgpa,name);
	}
//	scanf("%d",&roll);
//	scanf("%f",&cgpa);
//	scanf("%s",name);
	fp=fopen("C:/Users/kbhav/OneDrive/Documents/2nd sem/c practice/files/sample8.txt","w");
	if(fp==NULL)
	{
		printf("File not opend \n");
	}
	
	fclose(fp);
	return 0;
	
}
	
