#include<stdio.h>
int main()
{
FILE *FP;
int v=5214;
int v1;
FP=fopen("C:/Users/kbhav/OneDrive/Documents/2nd sem/c practice/files/practice/new.txt","w");
fwrite(&v,sizeof(v),1,FP);
fclose(FP);
FP=fopen("C:/Users/kbhav/OneDrive/Documents/2nd sem/c practice/files/practice/new.txt","r");
fread(&v1, sizeof(int),1, FP);
printf("%d",v1);
return 0;
}
