#include <stdio.h>

int main() {
    FILE *fp;
    int ca = 0, cc = 0, cv = 0, cw = 0, cs = 0;

    fp = fopen("C:/Users/kbhav/OneDrive/Documents/2nd sem/c practice/files/practice/p1.txt", "r");
    if (fp == NULL) {
        printf("File not opened");
        return 0;
    }

    char ch;
    while ((ch = fgetc(fp)) != EOF) {
        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
            ca = ca + 1;

            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') {
                cv = cv + 1;
            } else {
                cc = cc + 1;
            }
        } else if (ch == ' ' || ch == '.') {
            cw = cw + 1;
        }

        if (ch == '.') {
            cs = cs + 1;
        }
    }

    fclose(fp);

    printf("Number of alphabets: %d\n", ca);
    printf("Number of consonants: %d\n", cc);
    printf("Number of vowels: %d\n", cv);
    printf("Number of words: %d\n", cw);
    printf("Number of sentences: %d\n", cs);

    return 0;
}

