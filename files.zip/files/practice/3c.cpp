#include<stdio.h>
#include<string.h>
int main()
{
	FILE *fp;
	char s[30];
	fp=fopen("C:/Users/kbhav/OneDrive/Documents/2nd sem/c practice/files/practice/4.txt","w");
	if(fp==NULL)
	{
		printf("error in opening");
		
	}

do
{
	gets(s);
	fputs(s,fp);
	
}while(strlen(s)!=0);
printf("success");
fclose(fp);
return 0;
}
