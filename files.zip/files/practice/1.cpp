#include<stdio.h>
int main()
{
	FILE *fp;
	char ch;
	fp=fopen("C:/Users/kbhav/OneDrive/Documents/2nd sem/c practice/files/practice/s1.txt","w");
	if(fp==NULL)
	{
		printf("error in opening file");
		
	}
	printf("Enter a charecter");
	scanf("%c",&ch);
	fputc(ch,fp);
	fclose(fp);
	return 0;
}
