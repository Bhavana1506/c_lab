#include<stdio.h>
int main()
{
	FILE *fp;
	char c[100];
	fp=fopen("C:/Users/kbhav/OneDrive/Documents/2nd sem/c practice/files/practice/2.txt","r");
	if(fp==NULL)
	{
		printf("error in opening file");
	}
	fscanf(fp,"%[^\n]",c);
	printf("\n%s",c);
	fclose(fp);
	return 0;
	
}

