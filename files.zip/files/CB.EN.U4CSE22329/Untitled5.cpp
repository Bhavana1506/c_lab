#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    FILE *fp, *fp1, *fp2;
    char n1[100], n2[100];
    int i;

    fp = fopen("C:/Users/kbhav/OneDrive/Documents/2nd sem/c practice/files/f1.txt", "r");
    fp1 = fopen("C:/Users/kbhav/OneDrive/Documents/2nd sem/c practice/files/f2.txt", "r");
    fp2 = fopen("C:/Users/kbhav/OneDrive/Documents/2nd sem/c practice/files/file3.txt", "w");

    if (fp == NULL)
    {
        printf("\nCan't open file1 or file doesn't exist.");
        exit(0);
    }
    if (fp1 == NULL)
    {
        printf("\nCan't open file2 or file doesn't exist.");
        exit(0);
    }
    if (fp2 == NULL)
    {
        printf("\nCan't open file3 or file doesn't exist.");
        exit(0);
    }

    fscanf(fp, "%[^\n]", n1);
    fscanf(fp1, "%[^\n]", n2);

    for (i = 0; i < strlen(n1); i++)
    {
        if (n1[i] >= 'a' && n1[i] <= 'z')
        {
            fprintf(fp2, "%c", n1[i]);
        }
    }

    for (i = 0; i < strlen(n2); i++)
    {
        if (n2[i] >=48 && n2[i] <=57)
        {
            fprintf(fp2, "%c", n2[i]);
        }
    }

    fclose(fp);
    fclose(fp1);
    fclose(fp2);

    return 0;
}
