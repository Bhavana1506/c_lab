#include<stdio.h>
#include<string.h>
int main()
{
	char str[]="amrita";
	FILE *fp;
	fp=fopen("C:/Users/kbhav/OneDrive/Documents/2nd sem/c practice/files/sample7.txt","w");
	if(fp==NULL)
	{
		printf("File not opend \n");
	}
	int i;
	for(i=0;i<6;i++)
	{
		fputc(fp,str[i]);
	}
	fclose(fp);
}
	
