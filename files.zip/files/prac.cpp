#include <stdio.h>
#include <stdlib.h>
int main()
{
 int num;
 FILE *fptr;
 if ((fptr = fopen("C:\\program.txt","r")) == NULL){
 printf("Error! opening file");
 // Program exits if the file pointer returns NULL.
 exit(1);
 }
 fscanf(fptr,"%d", &num);
 printf("Value of n=%d", num);
 fclose(fptr); 
 return 0;
}


#include<stdio.h>
 void main()
 {
 FILE *fp;
 int roll;
 char name[25];
 float marks;
 char ch;
 fp = fopen("file.txt","w"); //Statement 1
 if(fp == NULL)
 {
 printf("\nCan't open file or file doesn't exist.");
 exit(0);
 }
 do
 {
 printf("\nEnter Roll : ");
 scanf("%d",&roll);
 printf("\nEnter Name : ");
 scanf("%s",name);
 printf("\nEnter Marks : ");
 scanf("%f",&marks);D
 fprintf(fp,"%d%s%f",roll,name,marks);
 printf("\nDo you want to add another data (y/n) : ");
 ch = getche();
 }while(ch=='y' || ch=='Y');
 printf("\nData written successfully...");
 fclose(fp);
 }
 
 
 
 #include<stdio.h>
 void main()
 {
 FILE *fp;
 char ch;
 fp = fopen("file.txt","r"); //Statement 1
 if(fp == NULL)
 {
 printf("\nCan't open file or file doesn't exist.");
 exit(0);
 }
 printf("\nData in file...\n");
 while((fscanf(fp,"%d%s%f",&roll,name,&marks))!=EOF) //Statement 2
 printf("\n%d\t%s\t%f",roll,name,marks);
 fclose(fp);
 }
 
 
 
 
 #include <stdio.h>
#include <stdlib.h> /* For exit() function */
int main()
{
 char sentence[1000];
 FILE *fptr;
 fptr = fopen("program.txt", "w");
 if(fptr == NULL)
 {
 printf("Error!");
 exit(1);
 }
 printf("Enter a sentence:\n");
 gets(sentence);
 fprintf(fptr,"%s", sentence);
 fclose(fptr);
 return 0;
}





#include <stdio.h>
int main()
{
 FILE *FP;
 int v=5214;
 int v1;
 FP=fopen("New","w");
 fwrite(&v,sizeof(v),1,FP);
 fclose(FP);
 FP=fopen("New","r");
 fread(&v1, sizeof(int),1, FP);
 printf("%d",v1);
 return 0;
}



int main()
{
 FILE *FP;
 int v[4]={5214,34,67,56};
 int v1[4];
 FP=fopen("New","w");
 int k= fwrite(v,sizeof(v),1,FP);
 printf("%d\n",k);
 fclose(FP);
 FP=fopen("New","r");
 fread(v1, sizeof(v1), 1, FP);
 for(int i=0;i<4;i++)
 {
 printf("%d\n",v1[i]);
 }
 return 0;
}





File positioning
*******************************************************************************/
#include<stdio.h>
int main()
{
 char name[10];
 FILE *fp;
 fp=fopen("New","wb");
 fputs("welcome",fp);
 printf("Current position : %ld \n",ftell(fp));
 rewind(fp);
 printf("Rewind position : %ld",ftell(fp));
 fclose(fp);
}
#include<stdio.h>
int main()
{
FILE *fp;
char ch[20]="welcome home";
char c;
int n=5;
fp = fopen("sample.txt","w");
fprintf(fp,"%s",ch);
printf("%ld\n",ftell(fp));
rewind(fp);
fseek(fp,4,0);
printf("%ld\n",ftell(fp));
fprintf(fp,"removed");
printf("%ld\n",ftell(fp));
 fseek(fp,-3,1); 
 printf("%ld\n",ftell(fp));
 fprintf(fp,"%d",n);
 printf("%ld\n",ftell(fp));
 fclose(fp);
}







#include <stdio.h>
int main ()
{
 FILE *fp;
 char data[60];
 fp = fopen ("New","w");
 fputs("Fresh2refresh.com is a programming tutorial website", fp);
 fclose(fp);
 fp = fopen ("New","r");
 fgets ( data, 60, fp );
 printf("%ld\n",ftell(fp));
 printf("Before fseek - %s\n", data); 
 // To set file pointet to 21th byte/character in the file
 fseek(fp, 21, SEEK_SET);
 fgets ( data, 60, fp );
 printf("After SEEK_SET to 21 - %s\n", data);
 
 rewind(fp);
 // To find backward 10 bytes from current position
 fseek(fp, 10, SEEK_CUR);
 fgets ( data, 60, fp );
 printf("After SEEK_CUR to -10 - %s\n", data);
 // To find 7th byte before the end of file
 fseek(fp, -7, SEEK_END); 
 fgets ( data, 60, fp );
 printf("After SEEK_END to -7 - %s\n", data)
 fclose(fp);
 return 0;
}







# include <stdio.h>
int main( )
{
 FILE *fp, *fp1;
 char data[50] ;
 printf( "Opening the file test.c in read mode \n" ) ;
 fp = fopen( "New", "r" );
 fp1=fopen("Old","w");
 if ( fp == NULL )
 {
 printf( "Could not open file test.c \n" ) ;
 return 1;
 }
 if ( fp1 == NULL )
 {
 printf( "Could not open file test.c \n" ) ;
 return 1;
 }
 printf( "Reading the file New \n" ) ;
 while(fgets ( data, 50, fp )!=NULL)
 {
 fputs(data,fp1);
 printf( "%s\n" , data ) ;
 }
 printf("Closing the file New") ;
 fclose(fp) ;
 return 0;






#include <stdio.h>
int main ()
{
 FILE *fp;
 int i=1, j=2, k=3, num;
 fp = fopen ("Sample","w");
 putw(i,fp);
 putw(j,fp);
 putw(k,fp);
 fclose(fp);
 fp = fopen ("Sample","r");
 while(!feof(fp))
 {
 num= getw(fp);
 printf("Data in Sample file is %d \n", num);
 }
 fclose(fp);
 return 0;
