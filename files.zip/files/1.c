#include<stdio.h>
int main()
{
	FILE *fp;
	fp=fopen("C:/Users/kbhav/OneDrive/Documents/2nd sem/c practice/files/sample.txt","r");
	if(fp==NULL)
	{
		printf("File not opend \n");
	}
	
	char ch;
	while(ch!=EOF)
	{
		ch=fgetc(fp);
	    printf("%c",ch);
	   
	}
	 fclose(fp);
	 //ch=fgetc(fp)
//	 while(ch!=EOF);
//	 {
//	 	printf("%c",ch);
//	 	ch=fgetc(fp);
//	 	
//	 }	
}
