#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

void lowercaseString(char* str) {
    while (*str) {
        *str = tolower(*str);
        str++;
    }
}

void lowercaseAndDigitsString(char* str) {
    while (*str) {
        if (isalpha(*str))
            *str = tolower(*str);
        else if (isdigit(*str))
            *str = *str;
        else
            *str = ' ';
        str++;
    }
}

int main() {
    FILE *file1, *file2, *file3;
    char str1[100], str2[100];

    file1 = fopen("file1.txt", "r");
    file2 = fopen("file2.txt", "r");
    file3 = fopen("file3.txt", "w");

    if (file1 == NULL || file2 == NULL || file3 == NULL) {
        printf("Error opening files.\n");
        exit(1);
    }

    fscanf(file1, "%[^\n]", str1);
    fscanf(file2, "%[^\n]", str2);

    lowercaseString(str1);
    lowercaseAndDigitsString(str2);

    fprintf(file3, "%s\n", str1);
    fprintf(file3, "%s\n", str2);

    fclose(file1);
    fclose(file2);
    fclose(file3);

    printf("Output written to file3.txt\n");

    return 0;
}
