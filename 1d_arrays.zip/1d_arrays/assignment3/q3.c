#include<stdio.h>
int main()
{
    int n,i,j,k,c=0;
    printf("enter no of elements in array");
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        printf("enter element in position %d ",i+1);
        scanf("%d",&a[i]);
    }
    printf("enter the element k ");
    scanf("%d",&k);
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if((a[i]-a[j])==k || a[j]-a[i]==k )
           {
            c=c+1;
           }
        }  
    } 
    printf("%d",c);
}