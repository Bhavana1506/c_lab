#include<stdio.h>
#include<math.h>
int main()
{
    int n,i,j,d,mind=999;
    printf("enter no of elements in array");
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            d=abs(a[i]-a[j]);
            if(d<mind)
            {
                mind=d;
            }
        }
    }
    printf("min diff is %d\n",mind);
}