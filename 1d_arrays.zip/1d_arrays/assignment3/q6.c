#include<stdio.h>
int main()
{
    int n,i,j,x;
    printf("enter no of elements in array");
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        printf("enter element in position %d ",i+1);
        scanf("%d",&a[i]);
    }
    
}