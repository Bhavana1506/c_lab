#include<stdio.h>
int main()
{
    int n,i,j,k,c=0;
    printf("enter no of elements in array");
    scanf("%d",&n);
    int a[n];
    int r[n];
    for(i=0;i<n;i++)
    {
        printf("enter element in position %d ",i+1);
        scanf("%d",&a[i]);
    }
    printf("to right");
    for(i=0;i<n-1;i++)
    {
        r[i]=a[i+1];
    }
    r[n-1]=a[0];
    for(i=0;i<n;i++)
    {
        printf("%d ",r[i]);
    }
    printf("\nto left");
    for(i=0;i<n-1;i++)
    {
        r[i+1]=a[i];
    }
    r[0]=a[n-1];
    for(i=0;i<n;i++)
    {
        printf("%d ",r[i]);
    }
}