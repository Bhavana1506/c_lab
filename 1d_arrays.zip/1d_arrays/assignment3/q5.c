#include<stdio.h>
int main()
{
    int n,i,j,sum,s=0;
    printf("enter no of elements in array");
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        printf("enter element in position %d ",i+1);
        scanf("%d",&a[i]);
    }
    printf("enter sum");
    scanf("%d",&sum);
    for(i=0;i<n;i++)
    {
        s=0;
        s=s+a[i];
        for(j=i+1;j<n;j++)
        {
           s=s+a[j];
           if(s==sum)
           {
            printf("sum found b/w indices %d and %d",i,j);
            break;
           }
        }
    }
}