#include<stdio.h>
int main()
{
    struct point 
    {
        int x;
        int y;
    };
}