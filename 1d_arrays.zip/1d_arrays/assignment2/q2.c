#include<stdio.h>
int main()
{
    int n,i,j,sum=0;
    printf("enter no of elements of array");
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        printf("enter element %d ",i+1);
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            sum=sum+(a[i]%a[j]);
        }
    }
    printf("%d",sum);
}