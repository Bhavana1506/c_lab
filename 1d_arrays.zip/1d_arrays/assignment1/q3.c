#include<stdio.h>
int main()
{
    int n,i,k,p;
    printf("enter no of elements in array ");
    scanf("%d",&n);
    int a[n+1];
    for(i=0;i<n;i++)
    {
        printf("enter element %d ",i+1);
        scanf("%d",&a[i]);
    }
    printf("enter the element to be inserted");
    scanf("%d",&k);
    printf("enter the position at which it is inserted");
    scanf("%d",&p);
    for(i=n;i>p-1;i--)
    {
     a[i]=a[i-1];
    }
    a[p-1]=k;
    printf("the element in array are ");
    for(i=0;i<=n;i++)
    {
      printf("%d ",a[i]);
    }
    return 0;
}