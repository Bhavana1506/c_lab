#include<stdio.h>
int main()
{
    int n,i,k,flag=1,start,end,mid;
    printf("enter no of elements in array ");
    scanf("%d",&n);
    int a[n+1];
    for(i=0;i<n;i++)
    {
        printf("enter element %d ",i+1);
        scanf("%d",&a[i]);
    }
    printf("enter the search element ");
    scanf("%d",&k);
    start=0;
    end=n-1;
    mid=(start+end)/2;
    while(start<end && flag==1)
   {
    if(a[mid]<k)
    {
        start=mid+1;
    }
    else if(a[mid]>k)
    {
        end=mid-1;
    }
    else
    {
        printf("element %d is present in position %d",k,mid+1);
        flag=0;
    }
    mid=(start+end)/2;
   } 
   if(flag==1)
   {
    printf("element is not present");
   }
}