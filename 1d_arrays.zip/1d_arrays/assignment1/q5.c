#include<stdio.h>
int main()
{
    int n,i,k,flag=1;
    printf("enter no of elements in array ");
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        printf("enter element %d ",i+1);
        scanf("%d",&a[i]);
    }
    printf("enter a element to search ");
    scanf("%d",&k);
    for(i=0;i<n;i++)
    {
        if(a[i]==k)
        {
            printf("the element %d is at position %d",k,i+1);
            flag=0;
            break;
        }
    }
    if(flag==1)
    {
        printf("element is not present in array");
    }
}