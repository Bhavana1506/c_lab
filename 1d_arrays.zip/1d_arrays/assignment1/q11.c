#include<stdio.h>
int main()
{
    int n,i,j,max,t;
    printf("enter no of elements in an array");
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        printf("enter the element %d ",i+1);
        scanf("%d",&a[i]);
    }
    for(i=0;i<n-1;i++)
    {
        max=i;
        for(j=i+1;j<n;j++)
        {
            if(a[j]>a[max])
            {
                max=j;
            }
        }
        t=a[i];
        a[i]=a[max];
        a[max=t];
    }
}