#include<stdio.h>
int main()
{
    int n,i,max,smax;
    printf("enter no of elements in an array");
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        printf("enter the element %d ",i+1);
        scanf("%d",&a[i]);
    }
    max=a[0];
    smax=a[0];
    for(i=1;i<n;i++)
    {
        if(a[i]>max)
        {
            smax=max;
            max=a[i];
        }
        else if(a[i]>smax && a[i]!=max)
        {
            smax=a[i];
        }
    }
    printf("%d is the second largest number",smax);
}
