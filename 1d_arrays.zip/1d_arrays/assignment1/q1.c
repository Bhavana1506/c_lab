#include<stdio.h>
int main()
{
    int n,i,c=0;
    printf("enter no of elements in an array");
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        printf("enter the element %d ",i+1);
        scanf("%d",&a[i]);
    }
    printf("negitive elements are");
    for(i=0;i<n;i++)
    {
        if(a[i]<0)
        {
            printf("%d",a[i]);
            c=c+1;
        }
    }
    printf("\ntotal no of negitive elements are %d",c);
}