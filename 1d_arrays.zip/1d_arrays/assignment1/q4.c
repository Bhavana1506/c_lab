#include<stdio.h>
int main()
{
    int n,i,p;
    printf("enter no of elements in array ");
    scanf("%d",&n);
    int t[n];
    for(i=0;i<n;i++)
    {
        printf("enter element %d ",i+1);
        scanf("%d",&t[i]);
    }
    printf("enter the position of element to be deleted");
    scanf("%d",&p);
    for(i=p;i<n;i++)
    {
        t[i-1]=t[i];
    }
    for(i=0;i<n-1;i++)
    {
        printf("%d ",t[i]);
    }
} 