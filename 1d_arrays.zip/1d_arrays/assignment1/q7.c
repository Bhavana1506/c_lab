#include<stdio.h>
int main()
{
    int n,i,j,c=1;
    printf("enter no of elements in array ");
    scanf("%d",&n);
    int a[n],f[n];
    for(i=0;i<n;i++)
    {
        printf("enter element %d ",i+1);
        scanf("%d",&a[i]);
        f[i]=-1;
    }
    for(i=0;i<n;i++)
    {
        c=1;
        for(j=i+1;j<n;j++)
        {
            if(a[i]==a[j])
            {
                c++;
                f[j]=0;
            }
        }
        if(f[i]!=0)
        {
            f[i]=c;
        }
    }
    for(i=0;i<n;i++)
    {
        if(f[i]!=0)
        {
            printf("\nthe frequency of %d is %d",a[i],f[i]);
        }
    }
    return 0;
}