#include <stdio.h>

int main()
 {
  int n, t;
  scanf("%d", &n);
  int a[n];
  for (int i = 0; i < n; i++)
   {
    scanf("%d", &a[i]);
   }
  scanf("%d", &t);
  if (n % 2 == 0)
   {
    for (int i = 0; i < n; i++) 
    {
      if (a[i] % 2 == 0) {
        printf("%d ", a[i]);
      }
    }
  } 
  else
   {
    int c = 0;
    for (int i = 0; i < n; i++)
     {
      if (a[i] % 2 == 0)
       {
        c++;
      }
      if (i + t >= n)
       {
        printf("%d ", c);
        c = 0;
      }
    }
  }

  printf("\n");

  return 0;
}
