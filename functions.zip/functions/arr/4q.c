#include <stdio.h>

int findMinElements(int arr[], int n) {
    int totalSum = 0;
    int currentSum = 0;
    int count = 0;

    // Calculate the total sum of all elements in the array
    for (int i = 0; i < n; i++) {
        totalSum += arr[i];
    }

    // Sort the array in descending order
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] < arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }

    // Find the minimum number of elements
    for (int i = 0; i < n; i++) {
        currentSum += arr[i];
        count++;
        if (currentSum > totalSum - currentSum) {
            break;
        }
    }

    return count;
}

int main() {
    int n,i;
    printf("enter the n value\n");
    scanf("%d",&n);
    
    printf("enter array elements\n");
    int arr[n];
    
    for(i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }

    int minElements = findMinElements(arr, n);
    printf("Minimum number of elements: %d\n", minElements);

    return 0;
}