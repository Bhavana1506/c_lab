#include<stdio.h>
void merge(int a[],int b[], int n, int m)
{
    int i=0;
    for(i=0;i<n;i++)
    {
        printf("%d",a[i]);
    }
    for(i=0;i<m;i++)
    {
        printf("%d",b[i]);
    }
}
int main()
{
    int n,m,i;
    scanf("%d%d",&n,&m);
    int a[n];
    int b[m];
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0;i<m;i++)
    {
        scanf("%d",&b[i]);
    }
    merge(a,b,n,m);
}
