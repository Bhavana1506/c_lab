#include<stdio.h>
int main()
{
    int i,n;
    scanf("%d",&n);
    int arr[n];
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    func(arr,n);
    return 0;
}
void func(int a[],int size)
{
    int i,j;
    for(i=0;i<size;i++)
    {
        for(j=0;j<a[i];j++)
        {
            printf("*");
        }
        printf("\n");
    }
}