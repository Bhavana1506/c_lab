#include<stdio.h>
void avgofsubject(int A[][6],int n,int m)
{
    int i,j;
    float s=0;
    for(j=0;j<m;j++)
    {
        for(i=0;i<n;i++)
        {
            s=s+A[i][j];
            
        }
        printf("Avg for Subject %d is %f\n",j,s);
    }
}
void avgofstudent(int A[][6],int n,int m)
{
    int i,j;
    float s=0;
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            s=s+A[i][j];
        }
        printf("Average of student %d is %f\n",i,s);
    }
}
void classtopper(int A[][6],int n,int m)
{
    int i,j;
    float s=0;
    float B[n];
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            s=s+A[i][j];
        }
        B[i]=s;
    }
    float max;
    int k=0;
    max=B[0];
    for(i=1;i<n;i++)
    {
        if(max<B[i])
        {
            max=B[i];
            k=i;
        }
    }
    printf("The Class Topper is : %f",k+1);
}
int main()
{
    int n,i,j,ch;
    scanf("%d",&n);
    int A[n][6];
    for(i=0;i<n;i++)
    {
        for(j=0;j<6;j++)
        {
            scanf("%d",&A[i][j]);
        }
    }
    scanf("%d",&ch);
    if(ch==1)
    {
       avgofsubject(A,n,6); 
    }
    if(ch==2)
    {
        avgofstudent(A,n,6);
    }
    if(ch==3)
    {
        classtopper(A,n,6);
    }
    
    
    
    
    
    
    
    
    
    
    
}