#include<stdio.h>

void highest(int a[4][3],int n,int m)
{
    int max,i,j;
    max=a[0][0];
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            if(a[i][j]>max)
            {
                max=a[i][j];
            }
        }
    }
    printf("highest mark is %d\n",max);
}
void totalmark(int a[4][3],int n,int m)
{
    int sum=0,i,j;
    for(i=0;i<n;i++)
    {
        sum=0;
        for(j=0;j<m;j++)
        {
            sum=sum+a[i][j];
        }
        printf(" total mark obtained by stu%d is %d\n",i+1,sum);
    }
    
}
void least(int a[4][3],int n,int m)
{
    int min,i,j;
    min=a[0][0];
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            if(min>a[i][j])
            {
                min=a[i][j];
            }
        }
    }
    printf("least score is %d\n",min);
}
int main()
{
    int i,j;
    int a[4][3];
    for(i=0;i<4;i++)
    {
        for(j=0;j<3;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    highest(a,4,3);
    totalmark(a,4,3);
    least(a,4,3);
}