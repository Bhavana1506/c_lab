#include<stdio.h>
void word(int a)
{
    int k,r,rev=0,sum=0;
    while(a!=0)
    {
        r=a%10;
        rev=(rev*10)+r;
        a=a/10;
    }
    while(rev!=0)
    {
      r=rev%10;
      if(r==0)
      {
        printf("Zero ");
      }
      else if(r==1)
      {
        printf("One ");
      }
      else if(r==2)
      {
        printf("Two ");
      }
      else if(r==3)
      {
        printf("Three ");
      }
      else if(r==4)
      {
        printf("Four ");
      }
      else if(r==5)
      {
        printf("Five ");
      }
      else if(r==6)
      {
        printf("Six ");
      }
      else if(r==7)
      {
        printf("Seven ");
      }
      else if(r==8)
      {
        printf("Eight ");
      }
      else if(r==9)
      {
        printf("Nine ");
      }
      rev=rev/10;
    }
}
int main()
{
    int a;
    scanf("%d",&a);
    word(a);
}