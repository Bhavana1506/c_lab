#include<stdio.h>
int difference(int a[],int n)
{
    int min,max,d,i;
    max=a[0];
    for(i=1;i<n;i++)
    {
        if(max<a[i])
        {
            max=a[i];
        }
    }
     min=a[0];
    for(i=1;i<n;i++)
    {
        if(min>a[i])
        {
            min=a[i];
        }
    }
    d=max-min;
    return d;
}
int main()
{
    int n,i,d;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    d=difference(a,n);
    printf("%d",d);
}