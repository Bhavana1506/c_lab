#include<stdio.h>
struct student
{
    char name[20];
    int id;
    float mark;
};
int main()
{
    struct student s={"Amrita",25,34.5};
    struct student t;
    t=s;
    printf("%s",t.name);
}