#include<stdio.h>
struct student
{
    char name[20];
    int id;
    float mark;
};
int main()
{
    struct student s[3];
    int i;
    struct student *q=&s[0];//s;
    for(i=0;i<3;i++)
    {
        scanf("%s",(q+i)->name);
        scanf("%d",&(q+i)->id);
        scanf("%f",&(q+i)->mark);
    }
    for(i=0;i<3;i++)
    {
        printf("%s\n",(q+i)->name);
        printf("%d\n",(q+i)->id);
        printf("%f\n",(q+i)->mark);
    }
    
}