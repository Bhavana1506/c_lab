#include<stdio.h>
struct student
{
    
    char name[21];
    int roll;
    struct dob
    {
        int date;
        int month;
        int year;
        char k;
    }d1,d2;
};
void display(struct student t)
{
    printf("%s",t.name);
    printf("%d",t.roll);
    printf("%d",t.d1.date);
    printf("%d",t.d1.month);
    printf("%d",t.d1.year);
}
int main()
{
    struct student s;
    scanf("%s",s.name);
    scanf("%d",&s.roll);
    scanf("%d",&s.d1.date);
    scanf("%d",&s.d1.month);
    scanf("%d",&s.d1.year);
    display(s);
}
