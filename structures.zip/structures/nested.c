#include<stdio.h>
// struct dob
    // {
    //     int date;
    //     int month;
    //     int year;
    //     char k;
    // };
struct student
{
    
    char name[21];
    int roll;
    struct dob
    {
        int date;
        int month;
        int year;
        char k;
    }d1;  // struct student d1;
};
int main()
{
    struct student s1;
    printf("%d\n",sizeof(s1.d1));
    printf("%d\n",sizeof(s1.name));
    printf("%d\n",sizeof(s1.roll));
    printf("%d\n",sizeof(s1.d1.month));
    printf("%d\n",sizeof(s1));
}
