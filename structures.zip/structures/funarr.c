#include<stdio.h>
struct student
{
    
    char name[21];
    int roll;
    struct dob
    {
        int date;
        int month;
        int year;
        char k;
    }d1,d2;
};
void display(struct student t[],int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("%s\n",t[i].name);
        printf("%d\n",t[i].roll);
        printf("%d",t[i].d1.date);
        printf("%d",t[i].d1.month);
        printf("%d\n",t[i].d1.year);
    }
    
}
int main()
{
    int n,i;
    scanf("%d",&n);
    struct student s[n];
    for(i=0;i<n;i++)
    {
        scanf("%s",s[i].name);
        scanf("%d",&s[i].roll);
        scanf("%d",&s[i].d1.date);
        scanf("%d",&s[i].d1.month);
        scanf("%d",&s[i].d1.year);
    }
    
    display(s,n);
}
