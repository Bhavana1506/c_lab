#include<stdio.h>
struct student
{
    char name[20];
    int id;
    float mark;
};
int main()
{
    struct student s;
    struct student *p=&s;
    // scanf("%s",pname);
    // scanf("%d",&pid);
    // scanf("%f",&pmark);
    // or use * .
    scanf("%s",(*p).name);
    scanf("%d",&(*p).id);
    scanf("%f",&(*p).mark);
    printf("%s",s.name);
    printf("%d",s.id);
    printf("%f",s.mark);
    
}