#include<stdio.h>
struct complex
{
    int real;
    int img;
};
int main()
{
    struct complex c1={2,3},c2={4,5},c3={0,0};
    c3.real=c1.real+c2.real;
    c3.img=c1.img+c2.img;
    printf("the result is %d+i%d",c3.real,c3.img);

}