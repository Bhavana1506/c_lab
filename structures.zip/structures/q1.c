#include<stdio.h>
struct employee
{
    char name[50];
    int id;
    float hra,ta,bp;
};
int main()
{
    struct employee e1,e2;
    printf("enter details of employee1");
    scanf("%s",e1.name);
    scanf("%d",&e1.id);
    scanf("%f",&e1.hra);
    scanf("%f",&e1.ta);
    scanf("%f",&e1.bp);

    printf("enter details of employee2\n");
    scanf("%s",e2.name);
    scanf("%d",&e2.id);
    scanf("%f",&e2.hra);
    scanf("%f",&e2.ta);
    scanf("%f",&e2.bp);
    float t1,t2;
    t1=e1.ta+e1.bp+e1.hra;
    t2=e2.ta+e2.bp+e2.hra;
    if(t1>t2)
    {
        printf("%s %d %f %f %f %f",e1.name,e1.id,e1.hra,e1.ta,e1.bp,t1);
    }
    else
    {
        printf("%s %d %f %f %f %f",e2.name,e2.id,e2.hra,e2.ta,e2.bp,t2);
    }

}