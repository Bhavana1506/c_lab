#include<stdio.h>
struct student
{
    
    int roll;
    // int mark[3];
    char name[30];
};
int main()
{
   
    int i;
    // struct student s={303,{20,30,35},"Anna"};
    // printf("%d\n",s.roll);
    // for(i=0;i<3;i++)
    // {
    //     printf("%d ",s.mark[i]);
    // }
    //  printf("\n");
    // printf("%s",s.name);
    int n;
    scanf("%d",&n);
    struct student s[n];
    // printf("%d",sizeof(s[0]));
    for(i=0;i<n;i++)
    {
        scanf("%d",&s[i].roll);
        scanf("%s",s[i].name);
    }
    for(i=0;i<n;i++)
    {
        printf("%d  %s\n",s[i].roll,s[i].name);
    }
}