#include<stdio.h>
struct student
{
    int roll;
    char name[20];
    int age;
    float marks;
};
void print(struct student s)
{
   printf("%d",s.roll);
   printf("%s",s.name);
   printf("%d",s.age);
   printf("%.2f",s.marks);
}
int main()
{
   struct student s1;
   scanf("%d",&s1.roll);
   scanf("%s",s1.name);
   scanf("%d",&s1.age);
   scanf("%f",&s1.marks);
   print(s1);
}