#include<stdio.h>
struct student
{
    int roll;
    char name[20];
    int age;
    float marks;
};
void prints2(struct student s[],int n)
{
    int i;
    for(i=0;i<5;i++)
    {
       if(s[i].roll==2)
       {
           printf("%d\n",s[i].roll);
           printf("%s\n",s[i].name);
           printf("%d\n",s[i].age);
           printf("%f\n",s[i].marks);
       }
    }
   
}
int main()
{
   struct student s1[5];
   int i;
   for(i=0;i<5;i++)
   {
      scanf("%d",&s1[i].roll);
      scanf("%s",s1[i].name);
      scanf("%d",&s1[i].age);
      scanf("%f",&s1[i].marks);
      
   }
   prints2(s1,5); 
   
}