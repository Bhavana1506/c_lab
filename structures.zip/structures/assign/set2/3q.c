#include<stdio.h>
struct home
{
    char name[20];
    struct address
    {
        int doorno;
        char street[20];
        char city[20];
        int pincode;
    }a;
    int no_units;
};
void bill(struct home h[],int n)
{
    int i;
    
    for(i=0;i<n;i++)
    {
        if(h[i].no_units<50)
        {
            printf("for house %d rate is %d",i+1,75);
        }
        else if(h[i].no_units>=51&&h[i].no_units<=200)
        {
            printf("for house %d rate is %d",i+1,1.25 * h[i].no_units);
        }
        else if(h[i].no_units>200)
        {
            printf("for house %d rate is %d",i+1,1.35 * h[i].no_units);
        }
    }
}
int main()
{
    int n,i;
    scanf("%d",&n);
    struct home h[n];
    for(i=0;i<n;i++)
    {
        scanf("%s",h[i].name);
        scanf("%d",&h[i].a.doorno);
        scanf("%s",h[i].a.street);
        scanf("%s",h[i].a.city);
        scanf("%d",&h[i].a.pincode);
        scanf("%d",h[i].no_units);
    }
    bill(h,n);
}