#include <stdio.h>
struct point
{
    int x;
    int y;
};
int checkforequilateral(struct point a, struct point b, struct point c)
{
    int s1, s2, s3;
    s1 = sqrt(pow(b.x - a.x, 2) + pow(b.y - a.y, 2));
}
int main()
{
    struct point a, b, c;
    scanf("%d", &a.x);
    scanf("%d", &a.y);
    scanf("%d", &b.x);
    scanf("%d", &b.y);
    scanf("%d", &c.x);
    scanf("%d", &c.y);
    if ((checkforequilateral(a, b, c)))
    {
        printf("equilateral");
    }
}