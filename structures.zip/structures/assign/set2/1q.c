#include <stdio.h>
#include<string.h>
struct cricket
{
    char p_name[20];
    char t_name[20];
    float batting_avg;
};
void teamwise(struct cricket p[], int n)
{
    int i, j;
    for (i = 0; i < n; i++)
    {
        printf("%s\n", p[i].t_name);
        for (j = 0; j < n; j++)
        {
        if(strcmp(p[i].t_name , p[j].t_name)==0)
         {
                printf("%s", p[j].p_name);
                printf("%.2f\n", p[j].batting_avg);
         }
        }
    }
}
int main()
{
    struct cricket player[5];
    int i;
    for (i = 0; i < 5; i++)
    {
        scanf("%s", player[i].p_name);
        scanf("%s", player[i].t_name);
        scanf("%f", &player[i].batting_avg);
    }
    teamwise(player, 5);
}