#include<stdio.h>
struct hotel
{
    char name[20];
    char address[30];
    int grade;
    float avg_charge;
    int no_rooms;
    
};
void grade(struct hotel h[],int n)
{
    int g,i;
    scanf("%d",&g);
    for(i=0;i<n;i++)
    {
        if(h[i].grade==g)
        {
            printf("%s",h[i].name);
            printf("%s",h[i].address);
            printf("%d",h[i].grade);
            printf("%f",h[i].avg_charge);
            printf("%d",h[i].no_rooms);
        }
    }
}
void roomcharge(struct hotel h[],int n)
{
    int i;
    float c;
    scanf("%f",&c);
    for(i=0;i<n;i++)
    {
        if(h[i].avg_charge<c)
        {
            printf("%s",h[i].name);
        }
    }
}
int main()
{
    int n,i;
    scanf("%d",&n);
    struct hotel h[n];
    for(i=0;i<n;i++)
    {
       scanf("%s",h[i].name);
       scanf("%s",h[i].address);
       scanf("%d",&h[i].grade);
       scanf("%f",&h[i].avg_charge);
       scanf("%d",&h[i].no_rooms);
    }
    int ch;
    scanf("%d",&ch);
    if(ch==1)
    {
        grade(h,n);
    }
    if(ch==2)
    {
        roomcharge(h,i);
    }
    
}