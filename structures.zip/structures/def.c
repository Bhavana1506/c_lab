#include<stdio.h>
#include<string.h>
struct student
{
    int roll_no;
    char name[20];
    float marks;
    char gender;
};  //}st1,st2;
int main()
{
    struct student st,st1;
    printf("enter the student details");
    scanf("%d%s %f %c",&st1.roll_no,st1.name,&st1.marks,&st1.gender);
    // st1.roll_no=12;
    // strcpy(st1.name,"amrita");
    // st1.marks=20.4;
    // st1.gender='f';
    // struct student st={23,"amrita",34.5,'f'},st1={24,"abc",40.5,'f'};
    // printf("%d\n",sizeof(st));
    // printf("%d %s %.2f %c\n",st.roll_no,st.name,st.marks,st.gender);
    printf("%d %s %.2f %c\n",st1.roll_no,st1.name,st1.marks,st1.gender);
}