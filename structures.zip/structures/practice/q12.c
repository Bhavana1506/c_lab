#include<stdio.h>
#include<string.h>
struct train
{
    int train_number;
    char from_station[20];
    char to_station[20];
    struct start_time
    {
        int h;
        int min;
        int sec;
    }t;
    int no_coaches;
    char train_type;
};
void starttimecoimbatore(struct train a[],int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        if(strcmp(a[i].from_station,"coimbatore")==0)
        {
            printf("%d",a[i].t.h);
            printf("%d",a[i].t.min);
            printf("%d",a[i].t.sec);
        }
    }
}
void coimbatoretobanglore(struct train a[],int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        if(a[i].from_station=="coimbatore" && a[i].to_station=="banglore")
        {
            printf("%d",a[i].train_number);
        }
    }
}
void tnoend(struct train a[],int n)
{
    int i,c=0;
    for(i=0;i<n;i++)
    {
        if((a[i].train_number%10)==6)
        {
            c=c+1;
        }
    }
    printf("no of trains with train number end with 6 are %d",c);
}
void passengerwith15(struct train a[],int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        if(a[i].train_type=='p'&& a[i].no_coaches>=15)
        {
            printf("%d",a[i].train_number);
            printf("%s",a[i].from_station);
            printf("%s",a[i].to_station);
            printf("%d",a[i].t.h);
            printf("%d",a[i].t.min);
            printf("%d",a[i].t.sec);
            printf("%d",a[i].no_coaches);
            printf("%c",a[i].train_type);
        }
    }
}
void desofcoaches(struct train a[],int n)
{
    int i,j;
    struct train temp;
    for(i=0;i<n-1;i++)
    {
        for(j=0;j<n-i-1;j++)
        {
            if(a[j].no_coaches<a[j+1].no_coaches)
            {
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }
    }
    for(i=0;i<n;i++)
    {
        printf("%d",a[i].train_number);
        printf("%s",a[i].from_station);
        printf("%s",a[i].to_station);
        printf("%d",a[i].t.h);
        printf("%d",a[i].t.min);
        printf("%d",a[i].t.sec);
        printf("%d",a[i].no_coaches);
        printf("%c",a[i].train_type);
    }
}
int main()
{
  int n,i;
  scanf("%d",&n);
  struct train a[n];
  for(i=0;i<n;i++)
  {
      scanf("%d",&a[i].train_number);
      scanf("%s",a[i].from_station);
      scanf("%s",a[i].to_station);
      scanf("%d",&a[i].t.h);
      scanf("%d",&a[i].t.min);
      scanf("%d",&a[i].t.sec);
      scanf("%d",&a[i].no_coaches);
      scanf(" %c",&a[i].train_type);
  }
  int ch;
  scanf("%d",&ch);
  if(ch==1)
  {
      starttimecoimbatore(a,n);
  }
  else if(ch==2)
  {
    coimbatoretobanglore(a,n);
  }
  else if(ch==3)
  {
    tnoend(a,n);
  }
  else if(ch==4)
  {
    passengerwith15(a,n);
  }

  else if(ch==5)
  {
    desofcoaches(a,n);
  }
}