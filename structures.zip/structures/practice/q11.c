#include<stdio.h>
struct employee
{
    char name[20];
    int id;
    float gp;
    struct dob
    {
        int date;
        int month;
        int year;
    }d;
};
void empgivenid(struct employee e[],int m,int ide)
{
    int i;
    for(i=0;i<m;i++)
    {
        if(e[i].id==ide)
        {
            printf("%s\n",e[i].name);
            printf("%d\n",e[i].id);
            printf("%f\n",e[i].gp);
            printf("%d",e[i].d.date);
            printf("%d",e[i].d.month);
            printf("%d",e[i].d.year);
        }
    }
}
void gpabove(struct employee e[],int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        if(e[i].gp>25000)
        {
            printf("%s\n",e[i].name);
            
        }
    }
}
void sort(struct employee e[],int n)
{
    int i,j;
    struct employee temp;
    for(i=0;i<n-1;i++)
    {
        for(j=0;j<n-i-1;j++)
        {
            if(e[j].gp>e[j+1].gp)
            {
                temp=e[j];
                e[j]=e[j+1];
                e[j+1]=temp;
            }
        }
    }
    for(i=0;i<n;i++)
    {
        printf("%s\n",e[i].name);
        printf("%d\n",e[i].id);
        printf("%f\n",e[i].gp);
        printf("%d",e[i].d.date);
        printf("%d",e[i].d.month);
        printf("%d",e[i].d.year);
    }
}
int main()
{
    int n,ch;
    scanf("%d",&n);
    struct employee e[n];
     int i;
    
    for(i=0;i<n;i++)
    {
        scanf("%s",e[i].name);
        scanf("%d",&e[i].id);
        scanf("%f",&e[i].gp);
        scanf("%d",&e[i].d.date);
        scanf("%d",&e[i].d.month);
        scanf("%d",&e[i].d.year);
    }
    scanf("%d",&ch);
    int ide;
    if(ch==1)
    {
        printf("enter the employee id\n");
        scanf("%d",&ide);
        empgivenid(e,n,ide);
    }
    if(ch==2)
    {
        gpabove(e,n);
    }
    if(ch==3)
    {
        sort(e,n);
    }
    
}