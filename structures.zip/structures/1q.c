#include<stdio.h>
struct cricket
{
    char name[20];
    char team_name[20];
    float avg;
    
};

int main()
{
    int i;
    struct cricket player[5];
    for(i=0;i<5;i++)
    {
        printf("enter the details of player %d",player[i+1]);
        scanf("%s",player[i].name);
        scanf("%s",player[i].team_name);
        sanf("%f",&player[i].avg);
    }
    
}
