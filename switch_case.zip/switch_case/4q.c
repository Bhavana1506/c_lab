#include<stdio.h>
int main()
{
    int n;
    printf("enter a number\n");
    scanf("%d",&n);
    switch(n>0)
    {
        case 1 :
        printf("%d is a positive",n);
        break;
        case 0 :
        switch (n<0)
        {
            case 1:
            printf("%d is a negitive number",n);
            break;
            case 0:
            printf("the number is equal to 0");
            break;
        }
    }
}