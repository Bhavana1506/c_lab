#include<stdio.h>
int main()
{
    int a,b;
    printf("enter 2 numbers\n");
    scanf("\n%d \n%d",&a,&b);
    switch (a>b)
    {
        case 1 :
        printf("%d is max",a);
        break;
        case 0:
        switch (a<b)
        {
            case 1 :
            printf("%d is max",b);
            break;
            case 0:
            printf("numbers are equal");
        }
    }
    return 0;

}