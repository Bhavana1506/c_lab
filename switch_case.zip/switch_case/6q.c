#include<stdio.h>
int main()
{
    char ch;
    int q,total=0;
    printf("B = Burger (Rs. 200)\n");
    printf("F = French Fries (Rs. 50)\n");
    printf("P = Pizza (Rs. 500)\n");
    printf("S = Sandwiches (Rs. 150)\n");
    printf("Enter the food type (B/F/P/S): ");
    scanf("%c", &ch);

    printf("enter quantity\n");
    scanf("%d", &q);
    switch(ch)
    {
        case 'B':
        total=q*200;
        break;
        case 'F':
        total=q*50;
        break;
        case 'P':
        total=q*500;
        break;
        case 'S':
        total=q*150;
        break;
        default:
        printf("invalid");
    }
    printf("total charges: %d\n",total);
    return 0;
}