#include<stdio.h>
int main()
{
 int a,b;
 char c;

 printf("+ for addition,- for substraction,* for multiplication,/ for division\n");
 scanf("%c",&c);
 printf("enter 2 numbers\n");
 scanf("\n%d %d",&a,&b);
 switch(c)
 {
    case '+':
    printf("result %d",a+b);
    break;
    case '-':
    printf("result %d",a-b);
    break;
    case '*':
    printf("result %d",a*b);
    break;
    case '/':
    printf("result %d",a/b);
    break;
    default:
    printf("invalid operation");
 }
 return 0;
}