#include<stdio.h>
int main()
{
    int ch;
    float area ,r,a,rs;
    printf("1:area of circle 2:area of square 3:area of sphere");
    printf("enter your choice");
    scanf("%d",&ch);
    switch(ch)
    {
        case 1:
        
        printf("enter radius of circle");
        scanf("%f",&r);
        area=3.14*r*r;
        printf("%f",area);
        break;
        case 2:
        
        printf("enter side length of square");
        scanf("%f",&a);
        area=a*a;
        printf("%f",area);
        break;
        case 3:
      
        printf("enter the radius of sphere");
        scanf("%f",&rs);
        area=4*3.14*rs*rs;
        printf("%f",area);
        break;
    }
    return 0;
}