#include<stdio.h>
int main()
{
     int m,n,i,j,k;
    scanf("%d",&m);
    scanf("%d",&n);
    int a[m][n] ,b[m][n],s[m][n],d[m][n],sm[m][n];
    printf("enter element in matrix 1\n");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("enter the element %d %d ",i+1,j+1);
            scanf("%d",&a[i][j]);
        }
    }
    printf("enter elements in matrix 2\n");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("enter the element %d %d ",i+1,j+1);
            scanf("%d",&b[i][j]);
        }
    }
    printf("enter a scalar to multiply matrix");
    scanf("%d",&k);
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
           s[i][j]=a[i][j]+b[i][j];
           d[i][j]=a[i][j]-b[i][j];
           sm[i][j]=k*a[i][j];
        }
    }
    printf("sum of matrices is");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
          printf("%d ",s[i][j]);
        }
        printf("\n");
    }
    printf("substraction of matrices is");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
          printf("%d ",d[i][j]);
        }
        printf("\n");
    }
printf("scalar multiplication  of matrices is");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
          printf("%d ",sm[i][j]);
        }
        printf("\n");
    }

}