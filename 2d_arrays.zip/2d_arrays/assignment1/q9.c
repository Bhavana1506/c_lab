#include<stdio.h>
int main()
{
    int n,i,j,flag=1;
    scanf("%d",&n);
    int a[n][n];
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("enter element %d %d",i+1,j+1);
            scanf("%d",&a[i][j]);
        }
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(i<j)
            {
                if(a[i][j]!=0)
                {
                flag=0;
                break;
                }
            }
        }
    }
    if(flag==1)
    {
        printf("lower triangular matrix");
    }
    else
    {
        printf("not a lower triangular matrix");
    }
    return 0;
}