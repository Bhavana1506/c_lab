#include<stdio.h>
int main()
{
    int n,i,j,sum=0,d1=0,d2=0;
    scanf("%d",&n);
    int a[n][n];
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("enter the element %d %d ",i+1,j+1);
            scanf("%d",&a[i][j]);
        }
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("%d ",a[i][j]);
        }
        printf("\n");
    }
    for(i=0;i<n;i++)
    {
        sum=0;
        printf("\nsum of row %d is ",i+1);
        for(j=0;j<n;j++)
        {
            sum=sum+a[i][j];
        }
        printf("%d",sum);
    }
    for(i=0;i<n;i++)
    {
        sum=0;
        printf("\nsum of coloumn %d is ",i+1);
        for(j=0;j<n;j++)
        {
            sum=sum+a[j][i];
        }
        printf("%d",sum);
    }
    for(i=0;i<n;i++)
    {
       d1=d1+a[i][i];
       d2=d2+a[i][n-i-1];
    }
    printf("\nsum of elements of diagonal1 is %d",d1);
    printf("\nsum of elements of diagonal2 is %d",d2);
    sum=0;
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(i<j)
            {
                sum=sum+a[i][j];
            }
        }
    }
    printf("\nthe sum of lower triangular elements is %d",sum);
    sum=0;
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(i>j)
            {
                sum=sum+a[i][j];
            }
        }
    }
    printf("\nthe sum of upper triangular elements is %d",sum);
    sum=0;
    for(i=0;i<n;i++)
        {
        for(j=0;j<n;j++)
            {
                sum=sum+a[i][j];
            }
        }
    printf("\nthe sum of all elements is %d",sum);
    return 0;
}