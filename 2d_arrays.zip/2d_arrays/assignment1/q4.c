#include<stdio.h>
int main()
{
     int m,n,i,j,k;
    scanf("%d",&m);
    scanf("%d",&n);
    int a[m][n],t[n][m];
    printf("enter element in matrix 1");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("enter the element %d %d ",i+1,j+1);
            scanf("%d",&a[i][j]);
        }
    }
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            t[j][i]=a[i][j];
        }
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            printf("%d ",t[i][j]);
        }
        printf("\n");
    }
    return 0;
}   