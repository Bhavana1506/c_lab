#include<stdio.h>
int main()
{
     int m,n,i,j,r,c;
    scanf("%d",&m);
    scanf("%d",&n);
    int a[m][n];
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("enter the element %d %d ",i+1,j+1);
            scanf("%d",&a[i][j]);
        }
    }
    printf("enter row number to be printed");
    scanf("%d",&r);
    for (i=0;i<n;i++)
    {
        printf("%d ",a[r-1][i]);
    }
    printf("enter coloumn number to be printed");
    scanf("%d",&c);
    for (i=0;i<m;i++)
    {
        printf("%d ",a[i][c-1]);
    }
    printf("\nenter row and coloumn number to be printed");
    scanf("%d%d",&r,&c);
    printf("%d",a[r-1][c-1]);  
}