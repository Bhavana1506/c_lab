#include<stdio.h>
int main()
{
    int n,j,i,trace=0;
    scanf("%d",&n);
    int a[n][n];
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("enter element %d %d",i+1,j+1);
            scanf("%d",&a[i][j]);
        }
    }
    for(i=0;i<n;i++)
    {
        trace=trace+a[i][i];
    }
    printf("trace is %d",trace);
    return 0;
}