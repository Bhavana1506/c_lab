#include<stdio.h>
#include<math.h>
int main()
{
    int n,i,k,r,sum=0,digit=0;
    printf("enter a number\n");
    scanf("%d",&n);
    k=n;
    while(k!=0)
    {
        k=k%10;
        digit=digit+1;
        k=k/10;
    }
    k=n;
    while(n!=0)
    {
        r=n%10;
        sum=sum+pow(r,digit);
        n=n/10;
    }
    n=k;
    if(n==sum)
    {
        printf("%d is a armstrong number",n);
    }
    else
    {
        printf("%d is not a armstrong number",n);
    }
    return 0;
}