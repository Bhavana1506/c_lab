#include<stdio.h>
int main()
{
    int n,i,sum=0;
    printf("enter number of terms");
    scanf("%d",&n);
    printf("the odd numbers are\n");
    for(i=1;i<=2*n;i=i+2)
    {
        printf("%d ",i);
        sum=sum+i;
    }
    printf("\nthe sum of odd natural numbers upto %d terms:%d",n,sum);
    return 0;
}