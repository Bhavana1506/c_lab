#include<stdio.h>
int main()
{
    int i,n,sum=0;
    printf("enter a number");
    scanf("%d",&n);
    printf("the positive divisior");
    for(i=1;i<n;i++)
    {
        if(n%i==0)
        {
            printf("%d ",i);
            sum=sum+i;
        }
    }
    printf("\nthe sum of the divisor is:%d",sum);
    if(n==sum)
    {
        printf("\nthe number is a perfect number");
    }
    else
    {
        printf("\nthe number is not perfect");
    }
    return 0;
}