#include<stdio.h>
int main()
{
    int i,n,j,cube;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        cube=1;
       for(j=1;j<=3;j++)
      {
        cube=cube*i;
       } 
       printf("Number is :%d and the cube is : %d\n",i,cube);
    }
    
    return 0;
}