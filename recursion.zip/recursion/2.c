#include<stdio.h>

//@start-editable@

 int product(int A[],int n)
 // write function definition here.
 {
     int p;
     if(n<=0)
     {
         return 1;
     }
     else
     {
         p = A[n] * product(A,n-1);
         return p;
     }
 }
 
 
 
 
 
 
 
 
 
 //@end-editable@


int main()
{
    int n;
    scanf("%d",&n);
    int A[n];
    for(int i=0; i< n; i++)
    {
    scanf("%d",&A[i]);
    }
    
    int p=product(A,n); // function call
    printf("%d",p);
    return 0;
}