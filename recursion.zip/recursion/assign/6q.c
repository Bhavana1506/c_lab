#include<stdio.h>
int countdigits(int n)
{
    int c;
    if(n<=0)
    {
        return 0;
    }
    else
    {
        return 1 + countdigits(n/10);
    }
} 
int main()
{
    int n,c;
    scanf("%d",&n);
    c=countdigits(n);
    printf("the number of digits in the number is : %d",c);
}