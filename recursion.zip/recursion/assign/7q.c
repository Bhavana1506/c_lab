#include<stdio.h>
int digitsum(int n)
{
    if(n<=0)
    {
        return 0;
    }
    else
    {
        return (n%10)+digitsum(n/10);
    }
}
int main()
{
    int n,s;
    scanf("%d",&n);
    s=digitsum(n);
    printf("the sum of digits of %d=%d",n,s);
}