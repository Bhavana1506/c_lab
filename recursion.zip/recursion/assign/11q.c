#include <stdio.h>

void decimalToBinary(int decimal) {
    if (decimal > 0) {
        decimalToBinary(decimal / 2);
        printf("%d", decimal % 2);
    }
}

int main() {
    int decimal;

    printf("Input any decimal number: ");
    scanf("%d", &decimal);

    printf("The Binary value of decimal no. %d is: ", decimal);
    decimalToBinary(decimal);
    printf("\n");

    return 0;
}
