#include <stdio.h>

int power(int base, int exponent) {
    if (exponent == 0) {
        return 1;
    }
    
    return base * power(base, exponent - 1);
}

int main() {
    int base, exponent;
    
    printf("Input the base value: ");
    scanf("%d", &base);
    
    printf("Input the value of power: ");
    scanf("%d", &exponent);
    
    int result = power(base, exponent);
    
    printf("The value of %d to the power of %d is: %d\n", base, exponent, result);
    
    return 0;
}
