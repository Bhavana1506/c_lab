#include<stdio.h>
void printarray(int a[],int n)
{
    if(n<=0)
    {
        return;
    }
    else
    {
        printf("%d ",a[n-1]);
        printarray(a,n-1);
    }
}
int main()
{
    int n,i;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    printarray(a,n);
}