#include<stdio.h>
#include<string.h>
void reverse(char s[],int n)
{
    if(n<=0)
    {
        return;
    }
    else
    {
        printf("%c",s[n-1]);
        reverse(s,n-1);
    }
}
int main()
{
    char s[50];
    gets(s);
    reverse(s,strlen(s));
    
}