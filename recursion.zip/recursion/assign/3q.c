#include<stdio.h>
int fibonacci(n)
{
    if(n<=1)
    {
        return 1;
    }
    else
    {
        return fibonacci(n-1)+fibonacci(n-2);
    }
}
int main()
{
    int n,i;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("%d ",fibonacci(i));
    }
}





#include <stdio.h>

int fibonacci(int n) {
    if (n <= 1) {
        return n;
    }
    
    return fibonacci(n - 1) + fibonacci(n - 2);
}

int main() {
    int numTerms;
    
    printf("Input number of terms for the Series: ");
    scanf("%d", &numTerms);
    
    printf("Fibonacci Series: ");
    for (int i = 0; i < numTerms; i++) {
        printf("%d ", fibonacci(i));
    }
    
    printf("\n");
    
    return 0;
}
