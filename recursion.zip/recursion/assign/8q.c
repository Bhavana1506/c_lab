#include<stdio.h>
int largest(int a[],int n)
{
    if(n==1)
    {
        return a[0];
    }
    else
    {
        int max=largest(a,n-1);
        return (a[n-1]>max)?a[n-1]:max;
    }
}
int main()
{
    int n,i,max;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    max=largest(a,n);
    printf("%d",max);
}