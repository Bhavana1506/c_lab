#include <stdio.h>

void printEven(int start, int end) {
    if (start > end) {
        return;
    }
    
    if (start % 2 == 0) {
        printf("%d ", start);
    }
    
    printEven(start + 1, end);
}

void printOdd(int start, int end) {
    if (start > end) {
        return;
    }
    
    if (start % 2 != 0) {
        printf("%d ", start);
    }
    
    printOdd(start + 1, end);
}

int main() {
    int start, end;
    
    printf("Input the range to print starting from 1: ");
    scanf("%d", &end);
    
    printf("All even numbers from 1 to %d are: ", end);
    printEven(1, end);
    printf("\n");
    
    printf("All odd numbers from 1 to %d are: ", end);
    printOdd(1, end);
    printf("\n");
    
    return 0;
}
