#include <stdio.h>

int search(int arr[], int n, int x) {
    if (n == 0) {
        return -1; 
    }
    
    if (arr[n - 1] == x) {
        return n - 1; 
    }
    
    return search(arr, n - 1, x); 
}

int main() {
    int arr[] = {1, 2, 3, 4, 5};
    int n = sizeof(arr) / sizeof(arr[0]);
    int x;
    
    printf("Enter the element to search: ");
    scanf("%d", &x);
    
    int index = search(arr, n, x);
    
    if (index == -1) {
        printf("Element not found.\n");
    } else {
        printf("Element found at index: %d\n", index);
    }
    
    return 0;
}
