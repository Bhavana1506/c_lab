#include <stdio.h>

void copyString(char source[], char destination[], int index) 
{
    destination[index] = source[index];
    
    if (source[index] != '\0') {
        copyString(source, destination, index + 1);
    }
}

int main() {
    char source[100], destination[100];
    
    printf("Input the string to copy: ");
    scanf("%s", source);
    
    copyString(source, destination, 0);
    
    printf("The string successfully copied.\n");
    printf("The first string is: %s\n", source);
    printf("The copied string is: %s\n", destination);
    
    return 0;
}
