#include<stdio.h>
// function declaration
void  numPrint(int B[],int k);

int main()
{
    int n;
    scanf("%d",&n);
    int A[n];
    for(int i=0; i< n; i++)
    {
    scanf("%d",&A[i]);
    }
    
    numPrint(A,n); // function call
    return 0;
}


  //@start-editable@

void numPrint(int B[],int k)
{
    if(k<=0)
    {
        return;
    }
    else
    {
        numprint(B,k-1);
        printf("%d",B[k-1]);
    }
}