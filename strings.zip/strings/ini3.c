#include<stdio.h>
int main()
{
    char e[5]={'b','a','d','\0'};
    printf("%s",e);
}