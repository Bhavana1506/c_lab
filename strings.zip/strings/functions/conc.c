#include<stdio.h>
#include<string.h>
int main()
{
    int i,j;
    char s1[30]="cse";
    char s2[20]="department";
    strcat(s1,s2);
    printf("%s",s1);
    puts(s2);
}