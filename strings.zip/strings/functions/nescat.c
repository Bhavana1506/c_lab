#include<stdio.h>
#include<string.h>
int main()
{
    int i,j;
    char s1[30]="welcome to";
    char s2[20]="c program";
    char s4[40];
    strcat(s4,strcat(s1,s2));
    puts(s1);
    puts(s2);
    puts(s4);
}