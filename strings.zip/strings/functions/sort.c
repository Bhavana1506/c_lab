#include<stdio.h>
#include<string.h>
int main()
{
    char s1[20],temp;
    int i,j;
    gets(s1);
    for(i=0;i<strlen(s1);i++)
    {
        for(j=i+1;j<strlen(s1);j++)
        {
            if(s1[i]>s1[j])
            {
                temp=s1[i];
                s1[i]=s1[j];
                s1[j]=temp;
            }
        }
    }
    puts(s1);
}