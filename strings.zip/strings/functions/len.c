#include<stdio.h>
#include<string.h>
int main()
{
    char s1[20]="program";
    char s2[20]={'p','r','o','g','r','a','m','\0'};
    char s3[20];
    printf("%d %d %d\n",strlen(s1),strlen(s2),strlen(s3));
    printf("%d %d %d\n",sizeof(s1),sizeof(s2),sizeof(s3));
    return 0;
}