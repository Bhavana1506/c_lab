#include<stdio.h>
#include<string.h>
int main()
{
    char s1[20]="program",s2[20];
    strcpy(s2,s1);
    puts(s1);
    puts(s2);
    return 0;
}