#include<stdio.h>
int main()
{
    char name[40];
    scanf("%[^\n]%*c",name);
    printf("%s",name);
}