#include<stdio.h>
int main()
{
    char a;
    a=getchar();
    putchar(a);
}