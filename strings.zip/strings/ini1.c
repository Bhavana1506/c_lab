#include<stdio.h>
int main()
{
    char b[7]="amrita";
    printf("%s",b);
    return 0;
}