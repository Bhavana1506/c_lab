#include<stdio.h>
#include<string.h>
int main()
{
    int i,c,j;
    char s[50],str[200];
    gets(s);
    for(i=0;i<strlen(s);i++)
    {
        if(s[i]>='A'&&s[i]<='Z')
        {
            c=(s[i])-64;
        }
        else if(s[i]>='a'&&s[i]<='z')
        {
            c=(s[i])-96;
        }
        for(j=0;j<c;j++)
        {
            if(c%2==0)
            {
               strcat(str,"@");
            }
            else
            {
                strcat(str,"!");
            }
        }
        
    }

    puts(str);
    return 0;
}