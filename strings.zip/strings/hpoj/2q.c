#include<stdio.h>
#include<string.h>
int main()
{
    int shift,i;
    char s[12];
    gets(s);
    for(i=0;i<strlen(s);i++)
    {
        if(s[i]>'A' && s[i]<'Z' )
        {
            if(s[i]>'0' && s[i]<'9')
            {
                if(s[i]>'a' && s[i]<'z')
                {
                    
                }
            }
        }
    }
    
}
