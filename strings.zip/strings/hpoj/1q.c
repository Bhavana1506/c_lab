#include<stdio.h>
#include<string.h>
int main()
{
    int shift,i;
    char s[50];
    gets(s);
    scanf("%d",&shift);
    for(i=0;i<strlen(s)-1;i++)
    {
        s[i]=s[i]+shift;
        if(s[i]>'z')
        {
            s[i]=s[i]-'z'+'a'-1;
        }
    }
    puts(s);
}
