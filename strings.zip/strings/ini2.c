#include<stdio.h>
int main()
{
    char d[]="good";
    printf("%s",d);
    return 0;
}