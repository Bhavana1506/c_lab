#include<stdio.h>
#include<string.h>
int main()
{
    int i,j;
    char s[30];
    int f[30];
    gets(s);
    for(i=0;i<strlen(s)-1;i++)
    {
        f[i]=-1;
    }
    f[i]=-1;
    for(i=0;i<strlen(s)-1;i++)
    {
        for(j=i+1;j<strlen(s)-1;j++)
        {
            if(s[i]==s[j])
            {
                f[j]=0;
            }
        }
    }
    for(i=0;i<strlen(s);i++)
    {
        if(f[i]!=0)
        {
            printf("%c",s[i]);
        }
    }
    return 0;
}