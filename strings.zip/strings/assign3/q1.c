#include<stdio.h>
#include<string.h>
int main()
{
    int i,j=0,len;
    char s1[30],r[30];
    gets(s1);
    for(i=strlen(s1)-1;i>=0;i--)
    {
        r[j]=s1[i];
        j++;
    }
    r[j]='\0';
    if(strcmp(s1,r)==0)
    {
        printf("palindrome");
    }
    else
    {
        printf("not a palindrome");
    }
    return 0;
}