#include<stdio.h>
int main()
{
    char a[10];
    scanf("%s",a);
    int i=0,c=0;
    while(a[i]!='\0')
    {
        c=c+1;
        i=i+1;
    }
    printf("length of string is %d",c);
}