#include<stdio.h>
int main()
{
    char s[70];
    gets(s);
    int len,i,cu=0,cl=0;
    for(i=0;s[i]!='\0';i++);
    len=i;
    for(i=0;i<len;i++)
    {
        if(s[i]>='A'&&s[i]<='Z')
        {
            cu=cu+1;
        }
        else if(s[i]>='a'&&s[i]<='z')
        {
            cl=cl+1;
        }
    }
    printf("no of upper case charecters is %d\n",cu);
    printf("no of lower case charecters is %d\n",cl);
}