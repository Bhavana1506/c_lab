#include<stdio.h>
int main()
{
    char s[50];
    gets(s);
    int len,i,cc=0,cd=0,cs=0;
    for(i=0;s[i]!='\0';i++);
    len=i;
    for(i=0;i<len;i++)
    {
        if(s[i]>='a'&&s[i]<='z')
        {
            s[i]=s[i]-32;
        }
    }
    printf("%s",s);
}