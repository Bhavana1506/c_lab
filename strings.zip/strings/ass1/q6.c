#include<stdio.h>
int main()
{
    char a[50];
    int i,len,cv=0,cc=0;
    gets(a);
    for(i=0;a[i]!='\0';i++);
    len=i;
    for(i=0;i<len;i++)
    {
        if(a[i]>='A'&&a[i]<='Z'||a[i]>='a'&&a[i]<='z')
        {
            if(a[i]=='A'||a[i]=='E'||a[i]=='I'||a[i]=='O'||a[i]=='U'||a[i]=='a'||a[i]=='e'||a[i]=='i'||a[i]=='o'||a[i]=='u')
            {
                cv=cv+1;
            }
            else
            {
                cc=cc+1;
            }
        }
    }
    printf("no of vowels are %d",cv);
    printf("no of consonents are %d",cc);
    return 0;
}