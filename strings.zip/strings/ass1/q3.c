#include<stdio.h>
int main()
{
    char s[40];
    printf("enter the string:");
    gets(s);
    int i;
    for(i=0;s[i]!='\0';i++);
    int len=i;
    printf("length of the string %d\n",len);
    printf("size of the string %d\n",sizeof(s));
    for(i=len;i>=0;i--)
    {
        putchar(s[i]);
    }
    return 0;
}