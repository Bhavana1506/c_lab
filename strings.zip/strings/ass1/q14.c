#include <stdio.h>
int main() 
{
   char s1[50], s2[50], cs[100];
   int i = 0, j = 0;
   printf("Enter string 1: ");
   gets(s1);
   printf("Enter string 2: ");
   gets(s2);
   while (s1[i] != '\0') 
   {
      cs[i] = s1[i];
      i++;
   }
   while (s2[j] != '\0')
    {
      cs[i] = s2[j];
      i++;
      j++;
   }
   cs[i] = '\0';
   printf("Concatenated string is: %s\n", cs);
   return 0;
}