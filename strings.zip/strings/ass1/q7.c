#include<stdio.h>
int main()
{
    char s[40];
    gets(s);
    printf("enter a charecter");
    char f;
    int len,i,c=0;
    scanf("%c",&f);
    for(i=0;s[i]!='\0';i++);
    len=i;
    for(i=0;i<len;i++)
    {
        if(s[i]==f)
        {
            c=c+1;
        }
    }
    printf("%c occurs %d times",f,c);
    return 0;
}