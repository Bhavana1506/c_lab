#include<stdio.h>
int main()
{
    char name[30];
    printf("enter name:");
    gets(name);
    printf("name:");
    puts(name);
}