#include<stdio.h>
int main()
{
    char s[30],ch;
    int i=0;
    printf("enter the string");
    while(ch!='\n')
    {
        ch=getchar();
        s[i]=ch;
        i++;
    }
    s[i]='\0';
    int len;
    for(i=0;s[i]!='\0';i++);
    len=i;
    for(i=0;i<len;i++)
    {
      putchar(s[i]); 
    }
    return 0;
}