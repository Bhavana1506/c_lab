#include<stdio.h>
int main()
{
    char s[70];
    gets(s);
    int len,i,cc=0,cd=0,cs=0;
    for(i=0;s[i]!='\0';i++);
    len=i;
    for(i=0;i<len;i++)
    {
        if(s[i]>='A'&&s[i]<='Z'||s[i]>='a'&&s[i]<='z')
        {
           cc=cc+1;
        }
        else if(s[i]>='0'&&s[i]<='9')
        {
           cd=cd+1;
        }
        else
        {
            cs=cs+1;
        }
    }
    printf("no of charecters are %d\n",cc);
    printf("no of digits are %d\n",cd);
    printf("no of symbols are %d\n",cs);
    
}