#include<stdio.h>
int main()
{
    char a[50];
    printf("enter string:\n");
    gets(a);
    int i;
    for(i=0;a[i]!='\0';i++);
    int len=i;
    printf("length of the string %d\n",len);
    printf("size of the string %d\n",sizeof(a));
    for(i=0;i<len;i++)
    {
        printf("charater %d is %c\n",i,a[i]);//putchar(a[i])
    }
    return 0;
}