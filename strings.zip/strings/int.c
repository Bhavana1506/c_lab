#include<stdio.h>
int main()
{
    char b[50];
    scanf("%s",b);
    printf("%s",b);
}